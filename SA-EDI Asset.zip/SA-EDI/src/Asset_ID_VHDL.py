##################################### Library ###############################
from __future__ import annotations
import os
from openai import OpenAI


import io
import re



import pdfplumber



import json
import sys

import pandas as pd



from pathlib import Path
import time




import pdfplumber


from collections import OrderedDict, defaultdict
from typing import List, Dict, Any, Tuple, Union, Optional

# from parsing_asset_prm import llm_parse_rtl_prm
# from parsing_asset_scd import llm_parse_rtl_scd


import shutil, tempfile, subprocess

###################################################### Ports and Signals Extraction ####################################################

def llm_parse_rtl_prm(vhdl_code):
    prompt = f"""
    You are provided with a complete VHDL RTL in the following delimited by <>.
    Input RTL : <{vhdl_code}>

    Note that, the provided code would contain either one or multiple VHDL entities.

    Task:
        Your task is to extract the names and functionalities of all the I/O ports declared inside the ***Input RTL***.

    Approach:
        1. Go through the provided RTL of all the VHDL entities one-by-one; even go over the commented-out lines in the RTL. A VHDL entity \
        starts with the keyword 'entity' and is of the following format:

            entity <entity_name> is
                Port (
                    Port1 : in  Type;
                    Port2 : out Type;
                );
            end <entity_name>;

            architecture <architecture_name> of <entity_name> is
                signal signal1, signal2 : Type;
            begin
                ....
                ....
            end <architecture_name>;

        2. Extract the names of all the I/O ports declared inside each entity. \
        A port declaration contains the keyword 'in' or 'out'. For example,
            Port1 : in  Type;
            Port2 : out Type;
        Here 'Port1' is a input port and 'Port2' is a output port. 'Type' can be any VHDL-supported data types (i.e, std_ulogic, std_logic etc.) or \
        customized ones.
        3. For each I/O port, analyze the RTL of the correponding module to learn about its functionalities.

    Constraint:
        Do not include any element that is not declared as I/O ports in the provided RTL. That means, exclude the elements that are just \
        mentioned or used, instead of being declared in the provided RTL.

    Output:
        While responding, generate following four fields for each of the element (I/O ports, signals and registers):
        "I/O Port": I/O port declaration name in RTL.
        "Entity": VHDL entity name in which the I/O port is declared.
        "Type": either 'input port' or 'output port' or 'inout port'.
        "Function": description of the functions of the I/O port in terms of the corresponding module in 1-2 sentences.
            

        Now respond strictly in the following json format with the following keys:
        {{
        "modules": [
            {{
                "Element": " ",
                "Entity": " ",
                "Type":  " ",
                "Function":  " "
            }},
            {{
                "Element": " ",
                "Entity": " ",
                "Type":  " ",
                "Function":  " "
            }}
        ]
        }}
    
    """


    response = client.chat.completions.create(
        model="gpt-5-mini",
        messages = [
            { "role": "system", "content": "You are a helpful assistant expertizing in hardware design" },
            {
                "role": "user",
                "content": prompt
            }
        ],
        max_tokens=10000,
        temperature= 0.05,
        response_format={
            "type": "json_object"
        }
    )
    parsed_rtl = response.choices[0].message.content.strip()
    print (parsed_rtl)

    parsed_rtl = json.loads(parsed_rtl)
              

    return parsed_rtl



def llm_parse_rtl_scd(vhdl_code):
    prompt = f"""
    You are provided with a complete VHDL RTL in the following delimited by <>.
    Input RTL : <{vhdl_code}>

    Note that, the provided code would contain either one or multiple VHDL entities.

    Task:
        Your task is to extract the names and functionalities of all the internal signals declared inside the ***Input RTL***.

    Approach:
        1. Go through the provided RTL of all the VHDL entities one-by-one; even go over the commented-out lines in the provided input RTL. A VHDL entity \
        starts with the keyword 'entity' and is of the following format:

            entity <entity_name> is
                Port (
                    Port1 : in  Type;
                    Port2 : out Type;
                );
            end <entity_name>;

            architecture <architecture_name> of <entity_name> is
                signal signal1, signal2 : Type;
            begin
                ....
                ....
            end <architecture_name>;

        2. Extract the names of all the internal signals declared inside each entity. \
        An internal signal declaration starts with the keyword 'signal'. For example,
            signal signal1, signal2 : Type;
        Here, signal1 and signal2 are two internal signals. Internal signals declaration can be of two types:
            Example 1:
                signal enable : std_ulogic;
                Here, enable is an internal signal.
            Example 2:
                    type fifo_t is record
                        we    : std_ulogic;
                        re    : std_ulogic;
                        clear : std_ulogic;
                        wdata : std_ulogic_vector(7 downto 0);
                        rdata : std_ulogic_vector(7 downto 0);
                        avail : std_ulogic;
                        half  : std_ulogic;
                        free  : std_ulogic;
                    end record;
                    signal fifo : fifo_t;
                    Here, the internal signals are 'fifo.we', 'fifo.re', 'fifo.clear', 'fifo.wdata', 'fifo.rdata', 'fifo.avail', 'fifo.half' and 'fifo.free'.
        3. For each internal signal, analyze the RTL of the correponding module to learn about its functionalities.

    Constraint:
        Do not include any element that is not declared as internal signal in the provided RTL. That means, exclude the elements that are just mentioned \
        or used, instead of being declared in the provided RTL.

    Output:
        While responding, generate following three fields for each of the internal signals:
        "Internal Signal": Internal signal declaration name in RTL.
        "Entity": VHDL entity name in which the internal signal is declared.
        "Function": description of the functions of the internal signal in terms of the corresponding module in 1-2 sentences.

            
        Now respond strictly in the following json format with the following keys:
        {{
        "modules": [
            {{
                "Internal Signal": " ",
                "Entity": " ",
                "Function":  " "
            }},
            {{
                "Internal Signal": " ",
                "Entity": " ",
                "Function":  " "
            }}
        ]
        }}
    
    """


    response = client.chat.completions.create(
        model="gpt-5-mini",
        messages = [
            { "role": "system", "content": "You are a helpful assistant expertizing in hardware design" },
            {
                "role": "user",
                "content": prompt
            }
        ],
        max_tokens=10000,
        temperature= 0.05,
        response_format={
            "type": "json_object"
        }
    )

    parsed_rtl = response.choices[0].message.content.strip()
    print (parsed_rtl)

    parsed_rtl = json.loads(parsed_rtl)

    return parsed_rtl

###################################################### Hierarchy Extraction ####################################################

def clone_repo(url):
    d = tempfile.mkdtemp(prefix="rtl_")
    subprocess.run(["git","clone","--depth","1",url,d],check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
    return d

def find_verilog(root):
    vv=[]
    for dp,_,fns in os.walk(root):
        for f in fns:
            if f.endswith((".v",".sv")): vv.append(os.path.join(dp,f))
    return vv

def extract_modules(path):
    mods={}; txt=open(path,"r",encoding="utf-8",errors="ignore").read()
    lines=txt.splitlines(keepends=True); inside=False; cur=None; buf=[]
    for ln in lines:
        if COMMENT_RE.match(ln) and not inside: continue
        if not inside:
            m = re.match(r"^\s*module\s+(\w+)", ln)
            if m: inside=True; cur=m.group(1); buf=[ln]
        else:
            buf.append(ln)
            if ENDMOD_RE.match(ln):
                mods[cur]="".join(buf); inside=False; cur=None; buf=[]
    return mods

def build_module_db(files):
    db={}
    for f in files: db.update(extract_modules(f))
    return db

def valid_inst_name(tok):
    tok=tok.strip()
    if not tok or tok[0] in ".{[" or "[" in tok or "]" in tok: return False
    return bool(IDENT_RE.match(tok))

def find_insts(code, mods):
    insts=[]; lines=code.splitlines(); n=len(lines); i=0
    while i<n:
        base=lines[i].split("//",1)[0].rstrip()
        if not base: i+=1; continue

        # CASE 1: mod #(
        m=re.match(r"\s*([A-Za-z_][A-Za-z0-9_$]*)\s*#\s*\($", base)
        if m and m.group(1) in mods:
            mod=m.group(1); depth=1; i+=1
            while i<n and depth>0:
                b=lines[i].split("//",1)[0]; depth+=b.count("("); depth-=b.count(")"); i+=1
            while i<n and not lines[i].split("//",1)[0].strip(): i+=1
            if i<n:
                line=lines[i].split("//",1)[0].strip()
                for part in line.split(","):
                    raw=part; p=part.strip()
                    if not p: continue
                    if "(" in raw:
                        p=p.split("(",1)[0].strip()
                        if valid_inst_name(p): insts.append({"child_module":mod,"inst_name":p})
                    else:
                        if valid_inst_name(p): insts.append({"child_module":mod,"inst_name":p})
            i+=1; continue

        # CASE 2: "mod" alone, then list
        m=re.match(r"\s*([A-Za-z_][A-Za-z0-9_$]*)\s*$", base)
        if m and m.group(1) in mods:
            mod=m.group(1); i+=1; stmt=[]
            while i<n:
                b=lines[i].split("//",1)[0].rstrip()
                if not b: i+=1; continue
                stmt.append(b)
                if ";" in b: break
                i+=1
            s="\n".join(stmt)
            for part in s.split(","):
                raw=part; p=part.split("//",1)[0].strip()
                if not p or "(" not in raw: continue
                p=p.split("(",1)[0].strip()
                if valid_inst_name(p): insts.append({"child_module":mod,"inst_name":p})
            i+=1; continue

        # CASE 3: "mod u1(...), u2(...);"
        m=re.match(r"\s*([A-Za-z_][A-Za-z0-9_$]*)\s*(?:#\s*\([^;]*\))?\s+(.+)", base)
        if m and m.group(1) in mods:
            mod=m.group(1); stmt=m.group(2)
            while ";" not in stmt and i+1<n:
                i+=1; stmt+="\n"+lines[i].split("//",1)[0]
            for part in stmt.split(","):
                raw=part; p=part.split("//",1)[0].strip()
                if not p or "(" not in raw: continue
                p=p.split("(",1)[0].strip()
                if valid_inst_name(p): insts.append({"child_module":mod,"inst_name":p})
            i+=1; continue

        i+=1
    return insts



# ----------------- VHDL SUPPORT -----------------

# Find .vhd / .vhdl files
def find_vhdl(root):
    vv = []
    for dp, _, fns in os.walk(root):
        for f in fns:
            if f.lower().endswith((".vhd", ".vhdl")):
                vv.append(os.path.join(dp, f))
    return vv


# Regexes for VHDL
VHDL_ENTITY_RE = re.compile(r"^\s*entity\s+([A-Za-z_]\w*)\s+is\b", re.IGNORECASE)
VHDL_INST_RE   = re.compile(
    r"^\s*([A-Za-z_]\w*)\s*:\s*(?:entity\s+[A-Za-z_]\w*\.)?([A-Za-z_]\w*)\b",
    re.IGNORECASE,
)


def extract_vhdl_entities(path):
    """
    Extract VHDL entities from a file and attach the corresponding code
    (entity + architecture etc.) to each entity name.

    Assumes typical IP style: one entity per file, or multiple entities
    appearing one after another in the same file.
    """
    txt = open(path, "r", encoding="utf-8", errors="ignore").read()
    lines = txt.splitlines(keepends=True)
    entities = {}

    n = len(lines)
    i = 0
    while i < n:
        line = lines[i]
        m = VHDL_ENTITY_RE.match(line)
        if m:
            ent_name = m.group(1)
            buf = [line]
            i += 1
            # Collect until the next 'entity' or EOF
            while i < n and not VHDL_ENTITY_RE.match(lines[i]):
                buf.append(lines[i])
                i += 1
            entities[ent_name] = "".join(buf)
        else:
            i += 1

    return entities


def build_vhdl_entity_db(files):
    db = {}
    for f in files:
        db.update(extract_vhdl_entities(f))
    return db


def find_vhdl_insts(code, entities):
    """
    Find entity/component instantiations inside VHDL code.

    Matches forms such as:
      u1 : submod
      u1 : entity work.submod
      u1 : submod
        generic map(...)
        port map(...);
    """
    insts = []
    for line in code.splitlines():
        # strip line comments
        line_nc = line.split("--", 1)[0].strip()
        if not line_nc:
            continue

        m = VHDL_INST_RE.match(line_nc)
        if not m:
            continue

        inst_label = m.group(1)
        child_ent  = m.group(2)

        # Only keep if this refers to a known entity in the design
        if child_ent in entities:
            insts.append({"child_module": child_ent, "inst_name": inst_label})

    return insts



##################### Extract Design hierarchy ######################################


def build_tree_list(startpath, indent="", tree_list=None):
    if tree_list is None:
        tree_list = []

    for item in os.listdir(startpath):
        path = os.path.join(startpath, item)
        if os.path.isdir(path):
            tree_list.append(indent + item)
            build_tree_list(path, indent + "    ", tree_list)
        else:
            tree_list.append(indent + item)

    return tree_list


############################## Read RAG output file ############################################

# def read_text(file_path):
#     with open(file_path, "r", encoding="utf-8") as f:
#         content = f.read()

#     return content



############################## OpenAI Call Function ################################################

# openai.api_key=os.getenv("OPENAI_API_KEY")

############################## CWE Database read function ###########################################

############################## CWE Database read function ###########################################

# def read_csv(file_path):
#     data = pd.read_csv(file_path)
#     return data.iloc[0:106, 0:5].to_string()
#     # return data.iloc[0:53, [0, 1, 4, 5, 10, 15, 16, 17, 18, 19]].to_string()



def read_csv_ipft(file_path):
    data = pd.read_csv(file_path)
    return data.iloc[0:15, [0, 1, 2]].to_string()


def read_csv_at(file_path):
    data = pd.read_csv(file_path)
    return data.iloc[0:7, [0, 1, 2]].to_string()

#############################################################################################################

def read_csv_conf(file_path):
    data = pd.read_csv(file_path)
    # return data.iloc[0:74, [0, 1, 2, 3, 8]].to_string()
    return data.iloc[0:74, [0, 1, 2, 3]].to_string()

def read_csv_intg(file_path):
    data = pd.read_csv(file_path)
    return data.iloc[0:59, [0, 1, 2, 3]].to_string()

def read_csv_avlb(file_path):
    data = pd.read_csv(file_path)
    return data.iloc[0:44, [0, 1, 2, 3]].to_string()

def read_csv_ipft(file_path):
    data = pd.read_csv(file_path)
    return data.iloc[0:15, [0, 1, 2]].to_string()


def read_csv_at(file_path):
    data = pd.read_csv(file_path)
    return data.iloc[0:7, [0, 1, 2]].to_string()

#############################################################################################################


def read_csv_short_conf(file_path):
    data = pd.read_csv(file_path)
    return data.iloc[0:74, [0, 1, 2]].to_string()


def read_csv_short_intg(file_path):
    data = pd.read_csv(file_path)
    return data.iloc[0:59, [0, 1, 2]].to_string()

def read_csv_short_avlb(file_path):
    data = pd.read_csv(file_path)
    return data.iloc[0:44, [0, 1, 2]].to_string()


################################### Read RTL ###############################################################

def read_rtl(file_path):
    try:
        with open(file_path, 'r', encoding="utf-8") as file:
            content = file.read()
        return content
    except FileNotFoundError:
        print(f"Error: File '{file_path}' not found.")
    except Exception as e:
        print(f"An error occurred: {e}")

####################################### Read Spec ###################################################################

def read_pdf(pdf_path):
    all_text = ""
    with pdfplumber.open(pdf_path) as pdf:
        for page in pdf.pages:
            page_text = page.extract_text()
            if page_text:
                all_text += page_text
    return all_text

############################################## Asset Name ###########################################################


def parse_hier_links(text: str):
    module_to_prefixes = defaultdict(list)
    for line in text.splitlines():
        line = line.strip()
        if not line:
            continue
        parts = line.split(".")
        prefix_parts = []
        for part in parts:
            m = re.match(r"([^(]+)\(([^)]+)\)$", part)
            if m:
                inst_name = m.group(1).strip()
                mod_name = m.group(2).strip()
                prefix_parts.append(inst_name)
                module_to_prefixes[mod_name].append(".".join(prefix_parts))
            else:
                prefix_parts.append(part)
                module_to_prefixes[part].append(part)
    return module_to_prefixes


def load_loose_json(obj):
    if isinstance(obj, (dict, list)):
        return obj

    text = obj
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass

    decoder = json.JSONDecoder()
    idx = 0
    length = len(text)
    objs = []

    while idx < length:
        while idx < length and text[idx].isspace():
            idx += 1
        if idx >= length:
            break

        obj, end = decoder.raw_decode(text, idx)
        objs.append(obj)
        idx = end

    return objs



def prefix_asset_names(data, module_to_prefixes):
    blocks = data if isinstance(data, list) else [data]
    for block in blocks:
        modules = block.get("VHDL Entities", [])
        for mod_entry in modules:
            mod_name = mod_entry.get("VHDL Entity")
            if not mod_name:
                continue
            assets = mod_entry.get("Assets", [])
            prefixes = module_to_prefixes.get(mod_name, [])
            if not prefixes:
                continue
            chosen_prefix = prefixes[0]
            for asset in assets:
                old_name = asset.get("Name")
                if not old_name:
                    continue
                if not old_name.startswith(chosen_prefix + "."):
                    asset["Name"] = f"{chosen_prefix}.{old_name}"
    return data


def flatten_assets(data):
    flat = []
    blocks = data if isinstance(data, list) else [data]
    for block in blocks:
        for mod_entry in block.get("VHDL Entities", []):
            for asset in mod_entry.get("Assets", []):
                flat.append(asset)
    return flat

#########################################################################################################




if __name__ == "__main__":

    # IP name
    SoC = "neorv32_wdt"


    # RTL directory
    project_path = rf"C:\Users\stdZi\OneDrive\Desktop\A_Paper\neorv32 RTL\{SoC}"


    # Output directory
    json_out = rf"SA-EDI\{SoC}\asset_list_{SoC}_out.json"


    # CWE directory
    csv_conf_path = r"C:\Users\stdZi\OneDrive\Desktop\FICS Research\SA-EDI\CWE_Database_Confidentiality.csv"
    csv_intg_path = r"C:\Users\stdZi\OneDrive\Desktop\FICS Research\SA-EDI\CWE_Database_Integrity.csv"
    csv_avlb_path = r"C:\Users\stdZi\OneDrive\Desktop\FICS Research\SA-EDI\CWE_Database_Availability.csv"

    # IP Family and Asset types directory
    ipft_path = r"C:\Users\stdZi\OneDrive\Desktop\FICS Research\SA-EDI\ipft.csv"
    at_path = r"C:\Users\stdZi\OneDrive\Desktop\FICS Research\SA-EDI\at.csv"


    client = OpenAI(
        api_key=os.getenv("UF_API_KEY"),
        base_url="https://api.ai.it.ufl.edu/v1"
    )


    REPO_URL  = None

    MOD_RE     = re.compile(r"^\s*module\s+(\w+)", re.MULTILINE)
    ENDMOD_RE  = re.compile(r"^\s*endmodule\b", re.MULTILINE)
    IDENT_RE   = re.compile(r"^[A-Za-z_][A-Za-z0-9_$]*$")
    COMMENT_RE = re.compile(r"^\s*//")







    ##############################################################################################################
    tree = build_tree_list(project_path)
    for line in tree:
        print(line)



    prompt_1 = f"""
    You are given a list of VHDL names from the RTL source folder of {SoC} design. 
    =========================
    File names:
    {tree}
    =========================

    Each file name begins with a common prefix and ends with the  .v, .sv extension. \
    Your task is to analyze the core component name in each file (i.e., the part of the file name excluding .v, .sv extension) \
    and provide a list of components in JSON format that excludes Generic Information components, like package file or uvm file or header file \
    with define staements.
        

    Output Format (JSON):
    {{
    "modules": [
        "Component 1",
        "Component 2"
        ...
        ]
    }}
    """


    # response = openai.ChatCompletion.create(
    #     model="gpt-4o",
    #     messages= [{"role": "user", "content": prompt_1}],
    #     max_tokens=1000,
    #     temperature= 0.01,
    #     response_format={"type": "json_object"}
    # )

    response = client.chat.completions.create(
        model="gpt-4o",
        messages = [
            { "role": "system", "content": "You are a helpful assistant expertizing in hardware design" },
            {
                "role": "user",
                "content": prompt_1
            }
        ],
        max_tokens=1000,
        temperature= 0.01,
        response_format={
            "type": "json_object"
        }
    )

    data_1 = response.choices[0].message.content.strip()
    print("\n \n \nThe Component list: \n", data_1)
    data_1 = json.loads(data_1)
    

    IPs = []

    for component in data_1["modules"]:
        IPs.append(component)

    print(IPs)



    #################################################################################################################################




    csv_conf_context = read_csv_conf(csv_conf_path)
    csv_intg_context = read_csv_intg(csv_intg_path)
    csv_avlb_context = read_csv_avlb(csv_avlb_path)

    csv_conf_context_short = read_csv_short_conf(csv_conf_path)
    csv_intg_context_short = read_csv_short_intg(csv_intg_path)
    csv_avlb_context_short = read_csv_short_avlb(csv_avlb_path)



    ipft_context = read_csv_ipft(ipft_path)
    at_context = read_csv_at(at_path)


    os.makedirs(rf"SA-EDI\{SoC}", exist_ok=True)

    # json_initial = rf"SA-EDI\{SoC}\asset_list_{SoC}_initial.json"
    # first_write_initial = True



    
    first_write = True

    # parsed_path = rf"SA-EDI\parsed_rtl.json"
    # if os.path.isfile(parsed_path):
    #     os.remove(parsed_path)

    #####################################################################################################################

    
    repo_dir = project_path if project_path else clone_repo(REPO_URL)

    # First try Verilog / SystemVerilog
    vf = find_verilog(repo_dir)
    mode = "verilog"



    if not vf:
        vf = find_vhdl(repo_dir)
        mode = "vhdl"

    if not vf:
        sys.exit(0)

    if mode == "verilog":   # Verilog mode
        modules   = build_module_db(vf)
        modnames  = set(modules.keys())
        inst_db   = {}
        inst_types= set()
        for m, code in modules.items():
            ii = find_insts(code, modnames)
            inst_db[m] = ii
            for ins in ii:
                inst_types.add(ins["child_module"])

    else:  # VHDL mode
        modules   = build_vhdl_entity_db(vf)     # <--- NEW
        modnames  = set(modules.keys())
        inst_db   = {}
        inst_types= set()
        for m, code in modules.items():
            ii = find_vhdl_insts(code, modnames) # <--- NEW
            inst_db[m] = ii
            for ins in ii:
                inst_types.add(ins["child_module"])

    tops = sorted(modnames - inst_types) or sorted(modnames)
    hier_links = []

    def dfs(cur, chain):
        children = inst_db.get(cur, [])
        if not children:
            top_mod = chain[0][1]
            parts   = [top_mod]
            for inst, mod in chain[1:]:
                parts.append(f"{inst}({mod})")
            hier_links.append(".".join(parts))
            return
        for ch in children:
            dfs(ch["child_module"], chain + [(ch["inst_name"], ch["child_module"])])

    for t in tops:
        dfs(t, [(t, t)])

    for link in hier_links:
        print(link)





    for IP in IPs:

        # rtl_path = f"{project_path}/{IP}.v"
        rtl_path = next((str(p) for ext in ('.sv', '.v', '.vhd') for p in Path(project_path).rglob(f"{IP}{ext}")), None)
        # print(rtl_path)
        rtl_sum = read_rtl(rtl_path)


        prm_element_list = llm_parse_rtl_prm(rtl_sum)
        scd_element_list = llm_parse_rtl_scd(rtl_sum)

        

        # sys.exit()

        question_1 = f"""
        First, I will try to provide you a very good understanding on assets in hardware security. After you understand the concepts very clearly, \
        I shall ask you to generate asset from the RTL codings of a design module.

        An asset is an I/O port (or internal signal/register) associated with the use-case flows of the module and represented in RTL, which involves \
        a security objective such as confidentiality, integrity, or availability (CIA). An example of an asset is data that a user wants to identify as a secret. \
        This data would, at least, require confidentiality as a security objective, thus making it an asset.


        **Conceptual Analysis of Hardware Security Objectives:**
        To start the Asset Identification methodology, you need to answer the following questions for each intended use case of the module in the IP.
        1. Confidentiality: Assume that the module is to be integrated into an IP or IC where confidentiality protections are required. Are there any I/O ports \
        (or internal signals/registers) in the module that can leak or expose material that an integrator may deem confidential?
        For example, is there any I/O port through which interfaces such information that may be considered secret? Or, is there any internal \
        signal/register which stores such information that may require confidentiality?
        2. Integrity : Assume that the module is to be integrated into an IP or IC where integrity protections are required. Are there any I/O ports \
        (or internal signals/registers) in the module that can modify material an integrator may deem as sensitive?
        For example, are there any I/O port (or internal signal/register) which hold such control state or configuration settings that need to be immutable during \
        certain operations or modes?
        3. Availability : Are there any I/O ports (or internal signals/registers) in the module that, if unavailable, would prohibit the operational behavior of \
        the module or IP?
        For example, are there any elements that could gate an output port or the use of an input port? The focus should be on elements that may be impacted \
        by a denial-of-service attack at the integration level.

        If the answer is 'Yes' to any of the questions above, then the I/O port (or internal signal) in question may be considered an asset in the module. \
        If the answer is 'No' to all the questions above, then it is probably safe to assume that the I/O port (or internal signal) is not an asset.



        **Example of Assets:**
        Below is an example of asset in a hardware architecture, to consolidate your understanding on assets in hardware security.
        This example is of a Gaussian Noise Generator (GNG) IP. \
        The GNG can be used in deep-learning models to add randomness to the input data or weights to make the neural network more robust to data variations. \
        It is frequently used in image detection and speech recognition.\
        ARCHITECTURE of Gaussian Noise Generator (GNG) IP:
        In a Gaussian Noise Generator, \
        Inputs “INIT_Z” are ports instead of parameters and ports “Addr_OvR” and “Split_Inp” were added to challenge the methodology and add to the analysis. \
        Another modification is the opaque “Swizzle” subsystem that simplifies the block diagram without impacting the assessment. \
        The GNG IP has three data input ports labeled “INIT_Z” that are initialization vectors to prime the linear feedback shift registers (LFSRs). \
        The “Split_Inp” is an output test port that is used to observe the randomness going into the split logic. The “Addr_OvR” port is used to override \
        the address created by the LZD logic for testing the coefficient ROM. The “Data_Out” is the Gaussian Noise produced by the IP.
        CONCEPTUAL ANALYSIS of Gaussian Noise Generator (GNG) IP:
        Start by applying the conceptual phase of the analysis by answering the questions related to security objectives.
        1. Confidentiality: Are there any elements in the IP that can leak or expose material that may need confidentiality?
        Answer: Yes. The output value of the XOR block can be deemed as a seed and, if observed, may be used to predict the GN. This assumes that the IP \
        considers GN as a secret. The asset would be the XOR and LFSR blocks.
        2. Integrity : Are there any elements in the IP that can modify material an integrator may deem as sensitive?
        Answer: Yes. The address into the Coeff ROM should not be modified once the “INIT_Z” inputs are set. Modifying the address to use a different \
        coefficient than the one intended may reduce the randomness of the GN. Therefore, the assets would be the ADDR block and Coeff ROM.
        3. Availability : Are there any elements in the IP that, if unavailable, can prohibit operational behavior?
        Answer: No. There is no means at the integration level to disable or impede “Data_Out.”
        All questions identified an asset except for question 3. The assets identified are XOR, LFSR, ADDR, Coeff ROM.


        **Example Types of Assets:**
        Below are some example types of assets in order to make you understand about assets in perspective of security objectives:
            - control port/signal/register: 'integrity' security objective. The name of the port/signal/register usually contains the keyword 'ctrl', 'control' etc.
            - enable port/signal/register: 'integrity' security objective. The name of the port/signal/register usually contains the keyword 'enable', 'en' etc.
            - read/write address port/signal/register: 'integrity' security objective. The name of the port/signal/register usually contains the keyword 'raddr', 'waddr', 'addr' etc.
            - read or output data port/signal/register: 'availability' security objective. The name of the port/signal/register usually contains the keyword 'rdata', 'data_o', 'data_out' etc.
            - write or input data port/signal/register: 'integrity' security objective. The name of the port/signal/register usually contains the keyword 'wdata', 'data_i', 'data_in' etc.
            - read enable port/signal/register: 'integrity' security objective. The name of the port/signal/register usually contains the keyword 'read', 're' etc.
            - write enable port/signal/register: 'integrity' security objective. The name of the port/signal/register usually contains the keyword 'write', 'we' etc.
            - plaintext or ciphertext port/signal/register: 'confidentiality' security objective. The name of the port/signal/register usually contains the keyword 'text' etc.
            - key port/signal/register: 'confidentiality' security objective. The name of the port/signal/register usually contains the keyword 'key' etc.
            - directional port/signal/register: 'integrity' security objective. The name of the port/signal/register usually contains the keyword 'dir', 'direction' etc.
            - select port/signal/register: 'integrity' security objective. The name of the port/signal/register usually contains the keyword 'sel', 'select' etc.
            - valid handshake port/signal/register: 'availability' security objective. The name of the port/signal/register usually contains the keyword 'valid', 'vld' etc.
            - ready handshake port/signal/register: 'availability' security objective. The name of the port/signal/register usually contains the keyword 'ready', 'rdy' etc.
            - acknowdgement handshake port/signal/register: 'availability' security objective. The name of the port/signal/register usually contains the keyword 'ack' etc.
            - request port/signal/register: 'integrity' security objective. The name of the port/signal/register usually contains the keyword 'req' etc.
            - done or finish port/signal/register: 'availability' security objective. The name of the port/signal/register usually contains the keyword 'done', 'finish' etc.
            - error flag or other status flag port/signal/register: 'integrity' security objective. The name of the port/signal/register usually contains the keyword 'error', 'err' 'fatal' etc.
            - clear port/signal/register: 'integrity' security objective. The name of the port/signal/register usually contains the keyword 'clear', 'clr' etc.

    
        Note that, there would be asset types other than the provided examples above; that means, an asset would not be just limited to the examples shown above. \
        Therefore, rely your analysis for assets on your conceptual understanding of hardware \
        security objectives; but be sure to include these examplery types of assets into your assets identification response for the design below.




        **Input:**
        Now, You are provided with the RTL of the **{IP}** below.
        =========================
        RTL of the {IP}:
        {rtl_sum}
        =========================
        This above data contains the RTL codings of the **{IP}**, which is a module in the {SoC} design.


        You are also given the list of all the I/O ports and internal signals of the **{IP}** in the following structured JSON format. 
        ======================
        **I/O ports' List**:
        {prm_element_list}
        ======================
        ======================
        **Internal signals' List**:
        {scd_element_list}
        ======================


        **Task:**
        Your task is to analyze the both of the provided RTL codings of the **{IP}** module for all the I/O ports in the \
        '**I/O ports' List**' and the internal signals in the **Internal signals' List**; and from these I/O ports (and internal signals), find three lists \
        of assets of the **{IP}**, where the lists are based on whether they are confidentiality-critical, integrity-critical and availability-critical. 



        **Method:**
            - Step 1: 
            At first, for each of the I/O ports in the **I/O ports' List** (and the internal signals in the **Internal signals' List**), check if \
            **the name of these elements** contains any of the following keywords from the above '**Example Types of Assets**' section: 
                A. 'error' or 'err' or 'fatal'
                B. 'ready' or 'rdy'
                C. 'en' or 'enable'
                D. 'ctrl' or 'control' 
                E. 'addr' or 'raddr' or 'waddr'
                F. 'rdata' or 'data_o' or 'data_out'
                G. 'data_i' or 'wdata' or 'data_in'
                H. 'read' or 're', 
                I. 'write' or 'we'
                J. 'text' ot 'key'
                K. 'dir'
                L. 'sel' or 'select'
                M. 'valid' or 'vld'
                N. 'ack'
                O. 'req'
                P. 'done' or 'finish'
                Q. 'clear' or 'clr'

            If the name contains any of the above keywords then infer that I/O port (or internal signal) as an asset with the relevant security objective. \
            These are the **preliminary assets**. For example, if the name of an I/O port is 'ops_en', the name contains the word segment 'en', that means \
            this is a enable port; so, 'ops_en' port is an asset with 'integrity' objective. 
            Do this step exhaustively, so that any I/O port (or internal signal) that contains one of the keyword-phrases or word-segments from this list is not \
            missed from analysis: . Take as much time as you need for your analysis.
        - Step 2:
            After extracting a list of preliminary assets from Step 1, Conduct a thorough and systematic analysis of the \
            RTL codings of the **{IP}** provided above, including the commented out lines inside the RTL, in order to get a detailed \
            understanding about the remaining I/O ports (and internal signals) other than the **preliminary assets**;
            Then, based on your learning about hardware security objectives from the above '**Conceptual Analysis of Hardware Security Objectives**' section as well \
            as different asset types based on the I/O ports' (or internal signals') functionality from the above '**Example Assets**' section, \
            find out for each of the remaining I/O ports (and internal signals) in the above '**Elements' List**' whether it can be an asset as well as the relevant security objective. \
            These are the **additional assets**.
            - Step 3:
            Finally, the comprehensive list of assets would be the summation of **preliminary assets** and **additional assets**.


        **Approach:**
            - For the analysis, take an extremely conservative approach. Only include those elements as assets which are absolutely and directly critical \
            from the security perspective. Use as many tokens as you need for your output.
            - If there are multiple VHDL entities, analyze the provided RTL codings of each of the VHDL entities \
            for all the I/O ports (or internal signals) for the corresponding VHDL Entity in order to extract assets.
            - For extracting the assets, focus rigorously on each of the I/O ports since they are most likely to get compromised by the attackers, rather than \
            internal signals.
            - Provide precise and thorough justifications for each asset's inclusion, as well as exclusion.


        **Constraints:**
            - For the analysis, do not include an element that is not directly critical from Confidentiality/Integrity/Availability perspective, as an asset.
            - The **{IP}** would have no confidentially-critical asset if it has no cryptographic relevance. Whether the **{IP}** is \
            used for cryptographic purposes or not would be evident from the analysis of above RTL codings.
            - Do not use your own knowledge to identify assets; rather, rely only on the analysis of the provied RTL codings of the **{IP}**.
            - Exclude structured I/O ports/signals (typed interfaces) as well as clock and reset ports/signals from assets.

            

        **Output:**
            While responding, generate following fields for each of the asset in each VHDL entity:-
            "VHDL Entity": name of the vhdl entity that has the asset declaration
            "Name": name of the asset (from the comprehensive list of assets) in RTL representation of the corresponding VHDL Entity.
            "Description": descrpiion of the asset in natural language in one 1-2 phrase, based on its functionality.
            "Security Objective": security analysis of the asset in terms of Confidentiality/Integrity/Availability.
            "Justification": precise explanation/reasoning in 1 or 2 sentences why you think the corresponding asset should considered. Do not provide explanations \
            based on the keywords; rather in your own words based on your understanding from the above '**Conceptual Analysis of Hardware Security Objectives**' \
            section.

            And, in the begining, "Module" key: {IP}
            
            Now respond strictly in the following json format:
            {{
            "Module": "",
            VHDL Entities: [
                {{
                    VHDL Entity: " ",
                    Assets: [
                    {{
                        "Name": " ",
                        "Description": " ",
                        "Security Objective":  " ",
                        "Justification":  " " 
                    }},
                    {{
                        "Asset Name": " ",
                        "Description": " ",
                        "Security Objective":  " ",
                        "Justification":  " " 
                    }}
                    ]
                }},
                {{
                    VHDL Entity: " ",
                    Assets: [
                    {{
                        "Name": " ",
                        "Description": " ",
                        "Security Objective":  " ",
                        "Justification":  " " 
                    }},
                    {{
                        "Name": " ",
                        "Description": " ",
                        "Security Objective":  " ",
                        "Justification":  " " 
                    }}
                    ]
                }}
                ]                
            }}

            If the **{IP}** module has no asset, return the output as empty with the "Module" key and Assets: [].
        """



    
        # response = openai.ChatCompletion.create(
        #     model="gpt-4o",
        #     # model="gpt-3.5-turbo",
        #     messages= [{"role": "user", "content": question_1}],
        #     max_tokens=10000,
        #     temperature= 0.01,
        #     response_format={"type": "json_object"}
        # )

        # response = openai.ChatCompletion.create(
        #     model="gpt-5-mini",
        #     # model="gpt-4o",
        #     messages= [{"role": "user", "content": question_1}],
        #     response_format={"type": "json_object"}
        # )

        response = client.chat.completions.create(
            model="gpt-4o",
            messages = [
                { "role": "system", "content": "You are a helpful assistant expertizing in hardware security as well as verification" },
                {
                    "role": "user",
                    "content": question_1
                }
            ],
            response_format={
                "type": "json_object"
            }
        )

        initial_asset_list = response.choices[0].message.content.strip()

        print("\nThe Initial Asset List: \n", initial_asset_list)
        initial_asset_list = json.loads(initial_asset_list)


        ##################################################################################################################################


        question_2 = f"""
        You are given a list of assets list of the *{IP}* in the {SoC} design, along with their relevant information, \
        according to the following structured JSON format. 
        =================================
        Assets List: 
        {initial_asset_list}
        =================================

        Also, You are provided with fifteen(15) different IP family types below:
        ==================================
        IP Family Types:
        {ipft_context}
        ==================================

        **Task**:
        Find out which IP family type is absolutely relevant for each asset. That means, for each asset, the appropriate IP family types that each asset \
        can be categorized into, need to be found.

        **Approach**:
        To do this, Follow these steps:
        1. Read through the **IP Family Types**; Analyze and learn about different IP family types from their definitions and examples.
        2. Go through the detailed hardware specifications of the **{IP}** and analyze the details/attributes/functions of each asset \
        in the **Assets List** provided above as much as possible.
        3. Compare this analysis of different assets with the learnt understanding of different IP family types. Do this analysis in a rigorously \
        conservative approach.


        **Constraints**:
        Do the step-by-step mapping analysis between each asset and IP family types, in a strictly conservative \
        approach. That means, for each asset, include only those IP family types that are directly relevant to that asset. Exclude the other ones. In addition, \
        Consider only the 15 types from **IP Family Types** provided above for the mapping analysis, no other \
        IP family types.
        Note that, each asset might have single or multiple or no IP family types associated with it.


        **Output**:
        Return a revised version of the input JSON, structured the same way, keeping all the fields' value as it is and adding one additional field for each asset:
            "Family": List of one or multiple IP family types for the corresponding asset.

        The response generated will be in the following json format:
            {{
            "Module": "",
            VHDL Entities: [
                {{
                    VHDL Entity: " ",
                    Assets: [
                    {{
                        "Name": " ",
                        "Description": " ",
                        "Security Objective":  " ",
                        "Family": [" ", " "],
                        "Justification":  " " 
                    }},
                    ...
                }},
                {{
                    VHDL Entity: " ",
                    Assets: [
                    {{
                        "Name": " ",
                        "Description": " ",
                        "Security Objective":  " ",
                        "Family": [" ", " "],
                        "Justification":  " "
                    }},
                    ...
                    ]
                }}
                ]                
            }}

        Optionally, you may improve the clarity or accuracy of valid entries if needed. If the provided Asset list is empty, the returned list will be empty as well.
        """



        # response = openai.ChatCompletion.create(
        #     model="gpt-5-mini",
        #     # model="gpt-4o",
        #     messages= [{"role": "user", "content": question_2}],
        #     response_format={"type": "json_object"}
        # )

        response = client.chat.completions.create(
            model="gpt-5-mini",
            messages = [
                { "role": "system", "content": "You are a helpful assistant expertizing in hardware design" },
                {
                    "role": "user",
                    "content": question_2
                }
            ],
            response_format={
                "type": "json_object"
            }
        )

        ip_asset_list = response.choices[0].message.content.strip()
        print("\nThe IPFT Asset List: \n", ip_asset_list)

        ip_asset_list = json.loads(ip_asset_list)

        ##################################################################################################################################


        question_3 = f"""
        You are given a list of assets list of the *{IP}* in the {SoC} design, along with their relevant information, \
        according to the following structured JSON format. 
        =================================
        Assets List: 
        {ip_asset_list}
        =================================

        Also, You are provided with seven(7) different Asset types below:
        ==================================
        Asset Types:
        {at_context}
        ==================================

        **Task**:
        Find out which Asset type is absolutely relevant for each asset. That means, for each asset, the appropriate asset types that each \
        asset can be categorized into, need to be found.

        **Approach**:
        To do this, Follow these steps:
        1. Read through the **Asset Types**; Analyze and learn about different Asset types from their definitions and examples.
        2. Go through the detailed hardware specifications of the **{IP}** and analyze the details/attributes/functions of each asset \
        in the **Assets List** provided above as much as possible.
        3. Compare this analysis of different assets with the learnt understanding of different Asset types. Do this analysis in a rigorously \
        conservative approach.


        **Constraints**:
        Do the step-by-step mapping analysis between each asset and Asset types, in a strictly conservative \
        approach. That means, for each asset, include only those Asset types that are directly relevant to that asset. Exclude the other ones. In addition, \
        Consider only the 7 types from **Asset Types** provided above for the mapping analysis, no other Asset types.
        Note that, each asset might have single or multiple or no Asset types associated with it.


        **Output**:
        Return a revised version of the input JSON, structured the same way, keeping all the fields' value as it is and adding one additional field for each asset:
            "Type": List of one or multiple Asset types for the corresponding asset.

        The response generated will be in the following json format:
            {{
            "Module": "",
            VHDL Entities: [
                {{
                    VHDL Entity: " ",
                    Assets: [
                    {{
                        "Name": " ",
                        "Description": " ",
                        "Security Objective":  " ",
                        "Family": [" ", " "],
                        "Type": [" ", " "],
                        "Justification":  " "
                    }},
                    ...
                }},
                {{
                    VHDL Entity: " ",
                    Assets: [
                    {{
                        "Name": " ",
                        "Description": " ",
                        "Security Objective":  " ",
                        "Family": [" ", " "],
                        "Type": [" ", " "],
                        "Justification":  " "
                    }},
                    ...
                    ]
                }}
                ]                
            }}

        Optionally, you may improve the clarity or accuracy of valid entries if needed. If the provided Asset list is empty, the returned list will be empty as well.
        """



        # response = openai.ChatCompletion.create(
        #     model="gpt-5-mini",
        #     # model="gpt-4o",
        #     messages= [{"role": "user", "content": question_3}],
        #     response_format={"type": "json_object"}
        # )

        response = client.chat.completions.create(
            model="gpt-5-mini",
            messages = [
                { "role": "system", "content": "You are a helpful assistant expertizing in hardware design" },
                {
                    "role": "user",
                    "content": question_3
                }
            ],
            response_format={
                "type": "json_object"
            }
        )

        ip_at_asset_list = response.choices[0].message.content.strip()
        print("\nThe IPFT-AT Asset List: \n", ip_at_asset_list)

        ip_at_asset_list = json.loads(ip_at_asset_list)

        #######################################################################################################################################



        question_4 = f"""
        You are given a list of assets list of the *{IP}* in the {SoC} design, along with their relevant information, \
        according to the following structured JSON format. 
        =================================
        Assets List: 
        {ip_at_asset_list}
        =================================


        Also, You are provided with three databases of hardware CWEs below, whose security objective is confidentiality, integrity and availability, respectively.
        ==========================================================
        Confidentiality-relevant CWE Database:
        {csv_conf_context}
        ==========================================================
        Integrity-relevant CWE Database:
        {csv_intg_context}
        ==========================================================
        Availability-relevant CWE Database:
        {csv_avlb_context}
        ==========================================================

        **Task**:
        Your task is to find, for each asset, whether any of the CWEs can attack the **{IP}** through each of the correponding assets.

        **Approach**:
        In my understanding, none of the CWEs in Database can attack through any of the asset. Hence, \
        analyze the CWE Database in order to understand if the provided CWEs can attack the design through the given assets, \
        and if so, specify the CWE(s), either one or two or three or four but not more than four CWEs, that would absolutely lead to the vulnerability for each asset. \
        Do the analysis in three independent stages under a extremely conservative approach. The extremely conservative approach of CWE mapping means that \
        for each asset, \
        only choose those CWE(s) selectively that would absolutely attack the **{IP}** module through that asset; discard the rest of the CWEs. \
        Do not pick the CWE(s)\
        on a case-specific basis, i.e., if-else condition. This approach is outlined \
        in 3 (three) stages as described below:


        'Stage 1 (Confidentiality)':
        Consider only the assets from the 'Asset List' whose 'Security Objective' field is Confidentiality. If no such asset, ignore this stage.
        Analyze the description of each of these CWEs (CWE-203, CWE-226, CWE-276, CWE-319, CWE-325, CWE-1191, CWE-1209, CWE-1220, CWE-1221, CWE-1224, CWE-1239, \
        CWE-1240, CWE-1241, CWE-1242, CWE-1243, CWE-1244, CWE-1247, CWE-1251, CWE-1252, CWE-1253, CWE-1254, CWE-1255, CWE-1257, CWE-1258, CWE-1259, CWE-1260, \
        CWE-1262, CWE-1263, CWE-1264, CWE-1266, CWE-1267, CWE-1268, CWE-1269, CWE-1270, CWE-1272, CWE-1273, CWE-1276, CWE-1277, CWE-1278, CWE-1279, CWE-1280, \
        CWE-1283, CWE-1290, CWE-1291, CWE-1292, CWE-1294, CWE-1295, CWE-1296, CWE-1297, CWE-1299, CWE-1300, CWE-1301, CWE-1302, CWE-1303, CWE-1304, CWE-1311, \
        CWE-1312, CWE-1313, CWE-1316, CWE-1317, CWE-1318, CWE-1319, CWE-1323, CWE-1328, CWE-1329, CWE-1330, CWE-1331, CWE-1332, CWE-1342, CWE-1384, CWE-1420, \
        CWE-1421, CWE-1422, CWE-1423) \
        from the Confidentiality-relevant CWE Database and provide reasoning under a extremely conservative approach whether they can attack any of the assets or \
        not. That means, consider only those CWEs that can directly attack through that corresponding asset; othewise, exclude the moderately or less likely CWEs. \
        Be sure to analyze each of the CWEs in the parenthesis in this stage. \
        If yes, list which of the CWE/CWEs do attack each of the considered assets through by which CWE/CWEs (list 1). 
        If you find any asset that not a single CWE would attack, remove that asset from consideration.
    
    
        'Stage 2 (Integrity)':
        Consider only the assets from the 'Asset List' whose 'Security Objective' field is Integrity. If no such asset, ignore this stage.
        Analyze the description of each of these CWEs (CWE-276, CWE-319, CWE-325, CWE-1189, CWE-1191, CWE-1209, CWE-1220, CWE-1221, CWE-1224, CWE-1242, CWE-1244, \
        CWE-1247, CWE-1251, CWE-1252, CWE-1253, CWE-1255, CWE-1256, CWE-1257, CWE-1259, CWE-1260, CWE-1262, CWE-1263, CWE-1267, CWE-1268, CWE-1269, CWE-1270, \
        CWE-1272, CWE-1273, CWE-1274, CWE-1276, CWE-1277, CWE-1279, CWE-1280, CWE-1281, CWE-1282, CWE-1290, CWE-1291, CWE-1292, CWE-1294, CWE-1295, CWE-1296, \
        CWE-1297, CWE-1299, CWE-1302, CWE-1304, CWE-1311, CWE-1312, CWE-1313, CWE-1316, CWE-1317, CWE-1318, CWE-1319, CWE-1328, CWE-1329, CWE-1332, CWE-1334, \
        CWE-1342, CWE-1351, CWE-1384) \
        from the Integrity-relevant CWE Database and provide reasoning under a extremely conservative approach whether they can attack any of the assets or not. \
        That means, consider only those CWEs that can directly attack through that corresponding asset; othewise, exclude the moderately or less likely CWEs. \
        Be sure to analyze each of the CWEs in the parenthesis in this stage. \
        If yes, list which of the CWE/CWEs do attack each of the considered assets through by which CWE/CWEs (list 2).
        If you find any asset that not a single CWE would attack, remove that asset from consideration.

        'Stage 3 (Availability)':
        Consider only the assets from the 'Asset List' whose 'Security Objective' field is Availability. If no such asset, ignore this stage.
        Analyze the description of each of these CWEs (CWE-1209, CWE-1220, CWE-1221, CWE-1224, CWE-1242, CWE-1245, CWE-1246, CWE-1247, CWE-1248, CWE-1251, CWE-1253, \
        CWE-1255, CWE-1257, CWE-1259, CWE-1260, CWE-1261, CWE-1267, CWE-1268, CWE-1269, CWE-1270, CWE-1272, CWE-1273, CWE-1276, CWE-1279, CWE-1281, CWE-1290, \
        CWE-1291, CWE-1292, CWE-1294, CWE-1295, CWE-1296, CWE-1297, CWE-1299, CWE-1302, CWE-1313, CWE-1314, CWE-1317, CWE-1318, CWE-1319, CWE-1320, CWE-1331, \
        CWE-1334, CWE-1338, CWE-1384) \
        from the Availability-relevant CWE Database and provide reasoning under a extremely conservative approach whether they can attack any of the assets or \
        not. That means, consider only those CWEs that can directly attack through that corresponding asset; othewise, exclude the moderately or less likely CWEs. \
        Be sure to analyze each of the CWEs in the parenthesis in this stage. \
        If yes, list which of the CWE/CWEs do attack each of the considered assets through by which CWE/CWEs (list 3).
        If you find any asset that not a single CWE would attack, remove that asset from consideration.

        Finally, combine all the CWEs' list (list 1 to 3) from these three stages for corresponding assets. The combined CWEs' list will not have any duplicate entry.

        
        **Output**:
        Return a revised version of the input JSON, structured the same way, keeping all the fields' value as it is and omitting the "Justification" field and \
        adding two additional field for each asset:
            "CWEs": CWE-IDs that would attack the corresponding asset.
            "Database_ID" : The static string value - "MITRE CWE VIEW: Hardware Design".

        The response generated will be in the following json format:
            {{
            "Module": "",
            VHDL Entities: [
                {{
                    VHDL Entity: " ",
                    Assets: [
                    {{
                        "Name": " ",
                        "Description": " ",
                        "Family": [" ", " "],
                        "Type": [" ", " "]
                        "Database_ID" : "MITRE CWE VIEW: Hardware Design",
                        "Security Objective":  " ",
                        "CWEs": [" ", " "]
                    }},
                    ...
                }},
                {{
                    VHDL Entity: " ",
                    Assets: [
                    {{
                        "Name": " ",
                        "Description": " ",
                        "Family": [" ", " "],
                        "Type": [" ", " "],
                        "Database_ID" : "MITRE CWE VIEW: Hardware Design",
                        "Security Objective":  " ",
                        "CWEs": [" ", " "]
                    }},
                    ...
                    ]
                }}
                ]                
            }}

        The response will exclude any asset that any CWE can not be mapped to. Optionally, you may improve the clarity or accuracy of valid entries if needed.
        If the provided Asset list is empty, the returned list will be empty as well.

        Note that, the "CWEs" field would only include the CWE-IDs, not the name of the CWEs.
        """



        # response = openai.ChatCompletion.create(
        #     model="gpt-5",
        #     # model="gpt-4o",
        #     messages= [{"role": "user", "content": question_4}],
        #     response_format={"type": "json_object"}
        # )

        response = client.chat.completions.create(
            model="gpt-5-mini",
            messages = [
                { "role": "system", "content": "You are a helpful assistant expertizing in hardware security as well as threat modelling" },
                {
                    "role": "user",
                    "content": question_4
                }
            ],
            response_format={
                "type": "json_object"
            }
        )

        mapped_asset_list = response.choices[0].message.content.strip()
        print("\nThe Mapped Asset List: \n", mapped_asset_list)

        mapped_asset_list = json.loads(mapped_asset_list)





        question_5 = f"""
        You are provided with the RTL of the **{IP}** below.
        =========================
        RTL of the {IP}:
        {rtl_sum}
        =========================
        This above data contains the RTL codings of the **{IP}**, which is a module in the '{SoC}' design.


        You are provided with fifteen(15) different IP family types and seven(7) different Asset types below:
        ==================================
        IP Family Types:
        {ipft_context}
        ==================================
        Asset Types:
        {at_context}
        ==================================

        You are provided with three databases of hardware CWEs below, whose security objective is confidentiality, integrity and availability, respectively.
        ==========================================================
        Confidentiality-relevant CWE Database:
        {csv_conf_context_short}
        ==========================================================
        Integrity-relevant CWE Database:
        {csv_intg_context_short}
        ==========================================================
        Availability-relevant CWE Database:
        {csv_avlb_context_short}
        ==========================================================

        You are given a list of hardware assets in the following structured JSON format.
        ===================================
        Asset List:
        {mapped_asset_list}
        ===================================

        Task:
        Recheck whether-
            1. The asset is a true security asset of the **{IP}**
            2. The IP family types and Asset types are absolutely relevant for the corresponding asset
            3. The CWEs are very highly likely to attack the corresponding asset


        Note that, if an asset does not have any CWE associated with it, discard it from your asset output.
        Also, be sure not to change the value of the fields of each of the non-discarded assets.
        Now, return a refined version of the input JSON, structured the same way as the 'Asset List', but excluding any assets that are irrelevant or overly vague. \
        Optionally, you may improve the clarity or accuracy of valid entries if needed.
        If the Mapped Asset list is empty, the returned list will be empty as well.
        """



        # response = openai.ChatCompletion.create(
        #     # response = openai.chat.completions.create(
        #     model="gpt-4o",
        #     messages= [{"role": "user", "content": question_5}],
        #     max_tokens=15000,
        #     temperature= 0.05,
        #     response_format={"type": "json_object"}
        # )

        response = client.chat.completions.create(
            model="gpt-5-mini",
            messages = [
                { "role": "system", "content": "You are a helpful assistant expertizing in hardware security" },
                {
                    "role": "user",
                    "content": question_5
                }
            ],
            max_tokens=15000,
            temperature= 0.05,
            response_format={
                "type": "json_object"
            }
        )



        revised_asset_list = response.choices[0].message.content.strip()
        print("\nThe Revised Asset List: \n", revised_asset_list)


        # data = load_loose_json(revised_asset_list)




        # hier_map = parse_hier_links("\n".join(hier_links))

        # data = prefix_asset_names(data, hier_map)
        # assets_only = flatten_assets(data)


        # mode = 'w' if first_write else 'a'
        # with open(json_out, mode, encoding="utf-8") as f:
        #     for i, asset in enumerate(assets_only):
        #         if i > 0:
        #             f.write(",\n")
        #         f.write(json.dumps(asset, indent=4))


        # first_write = False


        data = load_loose_json(revised_asset_list)
        hier_map = parse_hier_links("\n".join(hier_links))
        data = prefix_asset_names(data, hier_map)
        assets_only = flatten_assets(data)

        mode = 'w' if first_write else 'a'
        with open(json_out, mode, encoding="utf-8") as f:
            for i, asset in enumerate(assets_only):
                if i > 0:
                    f.write(",\n")
                f.write(json.dumps(asset, indent=4))


        first_write = False 




 