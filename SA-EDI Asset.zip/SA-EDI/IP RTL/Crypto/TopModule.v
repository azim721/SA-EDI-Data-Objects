module TopModule(
   input clk,
   input reset,
   input [2:0] s,
   output reg fr2,
   output reg fr1,
   output reg fr0,
   output reg dfr
);
   // State machine to control the flow rate
   reg [2:0] state;
   always @(posedge clk or posedge reset) begin
       if (reset) begin
           state <= 0;
       end else begin
           case (state)
               0: begin
                   if (s[2]) begin
                       state <= 0;
                   end else if (s[1]) begin
                       state <= 1;
                   end else if (s[0]) begin
                       state <= 2;
                   end
               end
               1: begin
                   if (s[2]) begin
                       state <= 0;
                   end else if (s[1]) begin
                       state <= 1;
                   end else if (s[0]) begin
                       state <= 2;
                   end
               end
               2: begin
                   if (s[2]) begin
                       state <= 0;
                   end else if (s[1]) begin
                       state <= 1;
                   end else if (s[0]) begin
                       state <= 2;
                   end
               end
           endcase
       end
   end
   // Outputs
   always @(state) begin
       case (state)
           0: begin
               fr2 <= 0;
               fr1 <= 0;
               fr0 <= 0;
               dfr <= 0;
           end
           1: begin
               fr2 <= 0;
               fr1 <= 0;
               fr0 <= 1;
               dfr <= 0;
           end
           2: begin
               fr2 <= 0;
               fr1 <= 1;
               fr0 <= 1;
               dfr <= 0;
           end
           3: begin
               fr2 <= 1;
               fr1 <= 1;
               fr0 <= 1;
               dfr <= 1;
           end
       endcase
   end
endmodule